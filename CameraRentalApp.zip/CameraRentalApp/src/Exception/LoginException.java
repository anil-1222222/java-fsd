package Exception;


public class LoginException extends Exception{

	@Override
	public String toString() {
		return "You have Entered Wrong Login Details";
	}
	
	
	

}
