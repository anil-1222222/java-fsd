package login;

import java.util.ArrayList;
import java.util.List;


public class Camera {
	private int cameraId;
	private String Brand;
	private int Model;
	private double PricePerDay;
	private boolean Rented;
	
	public Camera(int cameraId, String brand, int model, double pricePerDay) {
		super();
		this.cameraId = cameraId;
		this.Brand = brand;
		this.Model = model;
		this.PricePerDay = pricePerDay;
	}
	
	

	public int getCameraId() {
		return cameraId;
	}

	public void setCameraId(int cameraId) {
		this.cameraId = cameraId;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public int getModel() {
		return Model;
	}

	public void setModel(int model) {
		Model = model;
	}

	public double getPricePerDay() {
		return PricePerDay;
	}

	public void setPricePerDay(double pricePerDay) {
		PricePerDay = pricePerDay;
	}

	public boolean isRented() {
		return Rented;
	}

	public void setRented(boolean rented) {
		Rented = rented;
	}


	@Override
	public String toString() {
		return "Camera [cameraId=" + cameraId + ", Brand=" + Brand + ", Model=" + Model + ", PricePerDay=" + PricePerDay
				+ ", Rented=" + Rented + "]";
	}


}
