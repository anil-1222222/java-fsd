package login;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class CameraOperations {
	
	public static List<Camera> camList = new ArrayList<>();
	
	public static void initList() {
		   camList.add(new Camera(1,"Canon",2023,1000));
		   camList.add(new Camera(2,"Nikon",2022,800));
		   camList.add(new Camera(3,"Sony",2020,700));
		   camList.add(new Camera(4,"Pentex",2021,500));
		   camList.add(new Camera(5,"Panasonic",2023,1500));
		   camList.add(new Camera(6,"Casio",2022,2000));
		   
		   
	   }

	public static  void addCamera() {
		Scanner scan=new Scanner(System.in);
        System.out.println("ENTER THE CAMERA BRAND - ");
		String brand=scan.next();

		System.out.println("ENTER THE MODEL - ");
		int model=scan.nextInt();

		System.out.println("ENTER THE PER DAY PRICE(INR) - ");
		double PricePerDay=scan.nextDouble();

		Camera temp=camList.get(camList.size()-1);
		int newCamId=temp.getCameraId()+1;
		Camera newCam=new Camera(newCamId, brand, model, PricePerDay);
		camList.add(newCam);
	
        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
	}

	public static void remove(int cameraId) {		
        if(cameraId>0 && cameraId<=camList.size()) {
        	camList.remove(cameraId-1);
        	System.out.println("CAMERA SUUCESSFULLY REMOVED FROM THE LIST.");
        }
        else {
        	System.out.println("CAMERA_ID NOT FOUND");
        }
	}
	
	public static void displayAllCameras() {	
		if(camList.isEmpty()) {
			System.out.println("NOT FOUND ANY DETAIL");
		}
		else {
			System.out.println("======================================================");
			System.out.printf("%-10s %-10s %-10s %-10s %-10s\n","CAMERA ID", "BRAND", "MODEL", "PRICE", "STATUS");
			System.out.println("======================================================");
			
            int id=1;
			for(Camera camera:CameraOperations.camList) {
            	System.out.printf("%-10s %-10s %-10s %-10.2f %-10s\n",id++, camera.getBrand(), camera.getModel(),
                        camera.getPricePerDay(), camera.isRented() ? "Rented" : "Available");
            }
            System.out.println("======================================================");
	}
	}
	
	
	public static void rentCamera() {
		Scanner sc=new Scanner(System.in);
		
		displayAllCameras();
		
		if(camList.isEmpty()) {
			System.out.println("Now,No camera available for rent");
			return;
		}
		
	System.out.print("ENTER THE CAMERA ID YOU WANT TO RENT - ");
	
	int cameraId=sc.nextInt()-1;
	
	if(cameraId>0 && cameraId<camList.size()) {
		Camera camera=camList.get(cameraId);
		
		if(camera.isRented()) {
			System.out.println("Already rented");
		}
		
		else {
			if(Wallet.getBal()>=camera.getPricePerDay()) {
				
				Wallet.withdraw(camera.getPricePerDay());
				camera.setRented(true);
				
				String output="YOUR TRANSACTION FOR CAMERA " +camera.getBrand() +" "+camera.getModel()+" With RENT INR." +camera.getPricePerDay()+" HAS SUCCESSFULLY COMPLETED.";
				System.out.println(output);
			}
			else {
				System.out.println("Insufficient wallet balance,please refill your wallet");
			}
		}
	}
	
	else {
		System.out.println("Invalid Camera id");
	}
	
	}
	
		
}
