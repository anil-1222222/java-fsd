package login;

import java.util.Scanner;

public class FirstPage {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
	
		System.out.println("+================================+");
		System.out.println("|  WELCOME TO CAMERA RENTAL APP  |");
		System.out.println("+================================+");
		
		System.out.println("PLEASE LOGIN TO CONTINUE -");
		System.out.print("USERNAME -");
		String uname=sc.next();
		
		if(uname.equals("Anil")) {
			CameraOperations.initList();
			mainMenu();
		}
		else {
			System.out.println("---------------------------------");
			System.out.println("|PLEASE ENTER VALID CREDINTIALS |");
			System.out.println("---------------------------------");
			main(args);
		}
	}
	
	
	public static void mainMenu() {
		System.out.println("- - - - - - - - - - - - - - ");
		System.out.println(" 1.MY CAMERA \n 2.RENT A CAMERA \n 3.VIEW ALL CAMERA \n 4.MY WALLET \n 5.EXIT");
		System.out.println("Enter your option from 1-5:");
		System.out.println("- - - - - - - - - - - - - -");
		Scanner sc=new Scanner(System.in);
		int option=sc.nextInt();

		switch(option) {

		case 1: 
			System.out.println("PLEASE LOGIN TO VIEW MY CAMERA DETAILS -");
			System.out.print("USERNAME -");
			String uname=sc.next();

			System.out.print("PASSWORD - ");
			String pwd=sc.next();
			
			if(uname.equals("Anil") && pwd.equals("Anil@123")) {
				subMenu();
			}
			else {
				System.out.println("---------------------------------");
				System.out.println("|PLEASE ENTER VALID CREDINTIALS |");
				System.out.println("---------------------------------");
                mainMenu();
			}
			break;
		
		case 2:
			CameraOperations.rentCamera();
	    	 mainMenu();
			break;
		case 3:
			
			ViewAllCameras.view();
	    	 mainMenu();
			break;
		
			
		case 4:
			Wallet.manageWallet();
	    	 mainMenu();
			break;
			
		case 5:
			System.exit(0);
		
        default:
        	System.out.println("Invalid option choosen");
        	System.out.println("choose a range between 1-5");
        	mainMenu();

		}
			
		
	}

	
	public static void subMenu() {
		System.out.println(" \n******************** ");
		System.out.println("  1.ADD  \n  2.REMOVE  \n  3.VIEW MY CAMERA  \n  4.GO TO PREVIOUS MENU ");
		System.out.println(" ******************** ");

		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		switch(choice) {
		case 1:
			CameraOperations.addCamera();
			subMenu();
			break;
		case 2:
			CameraOperations.displayAllCameras();
			System.out.print("ENTER THE CAMERA ID TO REMOVE - ");
			int id=sc.nextInt();
			CameraOperations.remove(id);
			subMenu();
			break;
			
		case 3:
			CameraOperations.displayAllCameras();
			subMenu();
			break;
			
		case 4:
			mainMenu();
			break;
		}
	}

}
