package login;

public class ViewAllCameras{

	public static void view(){
		
		System.out.println("List of All Available Camera: ");
		
				
		if(CameraOperations.camList.isEmpty()) {
			
			System.out.println("No Cameras available at the moment");
           

		}
		
		else {
			System.out.printf("%-10s %-10s %-10s %-10s %-10s\n","CAMERA ID", "BRAND", "MODEL", "PRICE", "STATUS");
            int id=1;
			for(Camera camera:CameraOperations.camList) {
            	System.out.printf("%-10s %-10s %-10s %-10.2f %-10s\n",id++, camera.getBrand(), camera.getModel(),
                        camera.getPricePerDay(), camera.isRented() ? "Rented" : "Available");
            }
            System.out.println("======================================================");
	}

	}

	 
	
}
