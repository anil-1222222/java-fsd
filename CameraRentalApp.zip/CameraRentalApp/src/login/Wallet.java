package login;

import java.util.Scanner;


public class Wallet {

	private static int bal=5000;

	public Wallet(int bal) {
		super();
		this.bal = bal;
	}

	public static  int getBal() {
		return bal;
	}

	public void setBal(int bal) {
		this.bal = bal;
	}

	@Override
	public String toString() {
		return "Wallet [bal=" + bal + "]";
	}
	
	public static void deposit(double amt) {
        bal += amt;
    }
 
    public static boolean withdraw(double amt) {
        if (amt <= bal) {
            bal -= amt;
            return true;
        }
        return false;
    }
    
    public static void manageWallet() {
    	
    	Scanner sc=new Scanner(System.in);
    	
    	System.out.println("\n My Wallet\n");
    	System.out.println("Your current wallet balance is INR \n"+Wallet.getBal());
    	
    	
    	System.out.println("Do you want to add more");
    	System.out.println("\\n 1.Yes \\n 2.No");
    	
    	int decide=sc.nextInt();
    	
    	switch(decide) {
    	case 1:
    		System.out.println("Enter the amount(In INR)");
    		double amount=sc.nextDouble();
    		Wallet.deposit(amount);
    		System.out.println("Your wallet balance updated successfully"+"\n"+" Your current balance:INR %.2f\n "+Wallet.getBal());
    		break;
    	
    	case 2:
    		break;
    		
    	default: 
    		//throw new InvalidDecision();
    		System.out.println("Invalid Decision");
    	}
    }
	
}
