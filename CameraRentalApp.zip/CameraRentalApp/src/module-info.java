/**
 * 
 */
/**
 * @author anil1
 *
 */
module CameraRentalApp {
}