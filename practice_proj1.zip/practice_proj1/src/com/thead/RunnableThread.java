package com.thead;

class RunnableThread1 implements Runnable{
	@Override
	public void run() {
		   for (int i = 0; i < 5; i++) {
		         System.out.println(Thread.currentThread().getId() + " Value " + i);
		   }
	}
}
public class RunnableThread{
	public static void main(String[] args) {
		RunnableThread1 rt=new RunnableThread1();
		Thread th=new Thread(rt);
		th.start();

	}

}
