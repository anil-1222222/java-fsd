package com.tri;

import java.util.Scanner;

public class TryCatch {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a num1 :");
		int num1=sc.nextInt();
		System.out.println("Enter a num2 :");
		int num2=sc.nextInt();
		
		try {
			double div=num1/num2;
			System.out.println("The Division of "+num1+" with "+num2+" is: "+div);
		}
		catch (Exception e) {
			System.out.println("AnyThing by Zero Not Possible");
		}
	}

}
