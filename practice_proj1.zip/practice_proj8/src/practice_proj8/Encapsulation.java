package practice_proj8;

class BankAccount{
	private float bal;

	public BankAccount(float bal) {
		super();
		this.bal = bal;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}

	@Override
	public String toString() {
		return "BankAccount [bal=" + bal + "]";
	}
	
}
public class Encapsulation {

	public static void main(String[] args) {
		BankAccount ob=new BankAccount(1000);
		System.out.println(ob.getBal());
		

	}

}
