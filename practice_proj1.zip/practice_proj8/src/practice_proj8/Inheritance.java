package practice_proj8;

class Account{
	int accNum=1234;
	int pin=9999;
}

class Hacker extends Account{
	void disp(){
		System.out.println(accNum);
		System.out.println(pin);
	}
	void ChangeData() {
		accNum=6789;
		pin=1010;
	}
}

public class Inheritance {

	public static void main(String[] args) {
		Hacker hack=new Hacker();
		hack.disp();
		hack.ChangeData();
		hack.disp();
	}

}
