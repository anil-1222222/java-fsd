package practice_proj9;


interface A{
	default void show() {
		System.out.println("Show method in Class a..");
	}
}
interface B{
	default void show() {
		System.out.println("Show method in Class b..");
	}
}

public class DimondShape implements A,B {

	public void show() {
		A.super.show();
		B.super.show();
	}
	
	

	public static void main(String[] args) {
	DimondShape s=new DimondShape();
	s.show();

	}

}
