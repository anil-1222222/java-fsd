package com.sleep;

class ThreadSleep extends Thread{
	public void run() {
		for(int i=1;i<=6;i++) {
		    System.out.println("Count :"+i+"seconds");
		    try {
		    	Thread.sleep(6000);
		    }
		    catch (Exception e) {
				e.printStackTrace();
			}
	}
	}
}

class WaitThread extends Thread{
	private Object lock;

	public WaitThread(Object lock) {
		super();
		this.lock = lock;
	}
	public void run() {
		synchronized (lock) {
			System.out.println("Waiting for notification..");
			try {
				lock.wait(3000);
			}catch (Exception e) {
				e.printStackTrace();
			}
			
			System.out.println("Notification Came..");
		}
	}
}
public class ThreadSleepWait {

	public static void main(String[] args) {
		ThreadSleep s=new ThreadSleep();
		s.start();

		Object lock=new Object();
		WaitThread wt=new WaitThread(lock);
		wt.start();
		
	}

}
