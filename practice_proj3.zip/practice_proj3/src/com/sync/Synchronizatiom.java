package com.sync;


class Counter {
    private int count = 0;

    public synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            count++;
            System.out.println("Incremented to: " + count);
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class IncrementThread extends Thread {
    private Counter counter;

    public IncrementThread(Counter counter) {
        this.counter = counter;
    }

    public void run() {
        counter.increment();
    }
}


public class Synchronizatiom {

	public static void main(String[] args) {
		Counter co=new Counter();
		IncrementThread thread1 = new IncrementThread(co);
        IncrementThread thread2 = new IncrementThread(co);
        thread1.start();
        thread2.start();

	}

}
