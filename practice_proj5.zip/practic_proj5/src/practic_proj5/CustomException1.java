package practic_proj5;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

class MathCalculator {
    public static int divide(int dividend, int divisor) throws CustomException {
        if (divisor == 0) {
            throw new CustomException("Cannot divide by zero");
        }
        return dividend / divisor;
    }
}


public class CustomException1 {
	
	public static void main(String[] args) {
        try {
            int result = MathCalculator.divide(10, 2);
            System.out.println("Result of division: " + result);

            // Attempting to divide by zero will throw a CustomException
            result = MathCalculator.divide(5, 0);
            System.out.println("This line will not be reached.");
        } catch (CustomException e) {
            System.out.println("Custom Exception caught: " + e.getMessage());
        }
    }

}

