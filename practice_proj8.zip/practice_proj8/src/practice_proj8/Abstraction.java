package practice_proj8;

abstract class Plane{
	abstract void takeOff();
	abstract void fly();
	abstract void land();
	
}

class CargoPlane extends Plane{

	@Override
	void takeOff() {
		System.out.println("Plane is takeOff..");
	}

	@Override
	void fly() {
		System.out.println("CargoPlane is Flying...");
	}

	@Override
	void land() {
		System.out.println("Plane is landing..");
	}
	
}
public class Abstraction {

	public static void main(String[] args) {
		CargoPlane p=new CargoPlane();
		p.takeOff();
		p.fly();
		p.land();

	}

}
