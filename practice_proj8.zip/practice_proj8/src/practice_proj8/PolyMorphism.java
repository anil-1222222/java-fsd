package practice_proj8;

public class PolyMorphism {

	int sum(int x,int y) {
		return x+y;
	}
	
	int sum(int x,int y,int z) {
		return x+y+z;
	}
	
	double sum(double x,double y) {
		return x+y;
	}
	
	double sum(int x,double y) {
		return x+y;
	}
	
	
	public static void main(String[] args) {
		PolyMorphism p=new PolyMorphism();
		System.out.println(p.sum(10,20));
		System.out.println(p.sum(10,20,30));
		System.out.println(p.sum(10.3,12.9));
		System.out.println(p.sum(10,20.9));
	}

}
