package com.proj1;

public class AccessModifier {
	
	public int a=10;  //public variable
	protected int b=20;  //protected Variable
	int c=30;  //Default Variable
	private int d=40;  //private Variable\
	
	//public method
	public void m1() {
		System.out.println("Public Method.....");
	}

	//protected method
	protected void m2() {
		System.out.println("protected Method.....");
	}
	
	//default method
	void m3() {
		System.out.println("default Method.....");
	}
		
	//private method
	private void m4() {
		System.out.println("private Method.....");
	}

	public void Display() {
		
		AccessModifier ob=new AccessModifier();	
		System.out.println("-----------INSIDE SAME CLASSS--------------");
		
		System.out.println("public Variable Value ::"+ob.a);
		ob.m1();  //public method call
		
		System.out.println("protected Variable Value ::"+ob.b);
		ob.m2();  //protected method call
		
		System.out.println("default Variable Value ::"+ob.c);
		ob.m3();  //default method call
		
		System.out.println("private Variable Value ::"+ob.d);
		ob.m4();  //private method call
		
		System.out.println();

	}

}
