package com.proj1;

import com.proj2.OutsidePackage;
import com.proj2.SubClassOutsidePackage;

public class Test1 {
	public static void main(String[] args) {
		AccessModifier ob=new AccessModifier();
		ob.Display();
		
		SubClassSamePackage ob1=new SubClassSamePackage();
		ob1.Display();
		
		SubClassOutsidePackage ob2=new SubClassOutsidePackage();
		ob2.Display();
		
		OutsidePackage ob3=new OutsidePackage();
		ob3.Display();
	}
	
}
