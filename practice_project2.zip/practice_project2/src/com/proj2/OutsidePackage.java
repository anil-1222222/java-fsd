package com.proj2;

import com.proj1.AccessModifier;

public class OutsidePackage extends AccessModifier{
	
public void Display() {
		
		AccessModifier ob=new AccessModifier();	
		System.out.println("-----------CLASS OUTSIDE PACKAGE--------------");
		
		System.out.println("public Variable Value ::"+ob.a);
		ob.m1();  //public method call
		
		/*
		System.out.println("protected Variable Value ::"+ob.b);
		ob.m2();  //protected method call
		
		System.out.println("default Variable Value ::"+ob.c);
		ob.m3();  //default method call
	
		System.out.println("private Variable Value ::"+ob.d);
		ob.m4();  //private method call
		*/
		
		System.out.println();
   }


}
