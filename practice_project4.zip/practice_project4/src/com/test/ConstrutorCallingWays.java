package com.test;

public class ConstrutorCallingWays {
	
	private int num;
	private String str;
	
	//Default Constructor
	ConstrutorCallingWays(){
		System.out.println("Default Constructor......");
	}
	
    //Parameterized Constructor
	public ConstrutorCallingWays(int num, String str) {
		this();
		this.num = num;
		this.str = str;
		 System.out.println("Parameterized Constructor.....");
	}

     //Copy constructor
	public ConstrutorCallingWays(ConstrutorCallingWays copy) {
		this(copy.num,copy.str);
		this.num = copy.num;
		this.str = copy.str;
		 System.out.println("Copy Constructor.....");
	}
	
	public static void main(String[] args) {
		//Calling copy Constructor
		ConstrutorCallingWays ob1=new ConstrutorCallingWays(100,"Anil");
		ConstrutorCallingWays ob2=new ConstrutorCallingWays(ob1);

	}

}
