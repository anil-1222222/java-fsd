package com.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;

public class ArrayList1 {
	
	
	public static void main(String[] args) {
		
		List<Integer> list=new ArrayList<Integer>();
		
		System.out.println("======add()=======");
		list.add(12);
		list.add(12);
		list.add(14);
		list.add(15);
		list.add(16);
		list.add(17);
		System.out.println(list.toString());
		
		System.out.println("=====add(index,element=======");
		list.add(1, 18);
		System.out.println(list.toString());
		
		System.out.println("=====get()=======");
		System.out.println(list.get(3));
		
		System.out.println("=====lastIndexOf()=======");
		System.out.println(list.lastIndexOf(list));
		System.out.println(list.indexOf(12));
		System.out.println(list.remove(4));
		System.out.println(list.retainAll(list));
		list.set(1, 20);
		System.out.println(list);
		
		Spliterator s=list.spliterator();
		System.out.println(s.getExactSizeIfKnown());
		s.forEachRemaining(System.out::println);
		

		   System.out.println("*******iterator()*********");
		   Iterator iter=list.iterator();
	       while(iter.hasNext()) {
	             System.out.println(iter.next());
	                }
	}	

}
