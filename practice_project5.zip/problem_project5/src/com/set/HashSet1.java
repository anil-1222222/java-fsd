package com.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Spliterator;

public class HashSet1 {

	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		HashSet<Integer> set=new HashSet<Integer>();
		   
		   System.out.println("*******Add()*********");
		   set.add(12);
		   set.add(13);
		   set.add(14);
		   set.add(18);
		   set.add(16);
		   set.add(13);
		   System.out.println(set.toString());
		   
		   System.out.println("*******addAll()*********");
		   HashSet<Integer> set1=new HashSet<Integer>();
		   set1.addAll(set);
		   System.out.println(set1.toString());
		   
		   System.out.println("*******clear()*********");
		   set1.clear();
		   System.out.println(set1.toString());
		   
		   System.out.println("*******contains()*********");	 
		   System.out.println(set.contains(14));
		   
		   System.out.println("*******isEmpty()*********");	 
		   System.out.println(set.isEmpty());
		   System.out.println(set1.isEmpty());
		   
		   System.out.println("*******iterator()*********");
		   Iterator<Integer> iter=set.iterator();
	       while(iter.hasNext()) {
	             System.out.println(iter.next());
	                }
	       
	       System.out.println("*******Spliterator()*********");
	       Spliterator<Integer> spltr=set.spliterator();
	       spltr.forEachRemaining(System.out::println);
	       
	       System.out.println("*******remove()*********");
		   set.remove(18);
		   System.out.println(set.toString());
		   
		   System.out.println("*******size()*********");	 
		   System.out.println(set.size());
		   
		}

}
