package com.set;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Spliterator;

public class LinkedHashSet1 {
	public static void main(String[] args) {
		   LinkedHashSet<Integer> set=new LinkedHashSet<Integer>();
		   
		   System.out.println("*******Add()*********");
		   set.add(12);
		   set.add(13);
		   set.add(14);
		   set.add(18);
		   set.add(16);
		   System.out.println(set.toString());
		   
		   System.out.println("*******addAll()*********");
		   LinkedHashSet<Integer> set1=new LinkedHashSet<Integer>();
		   set1.addAll(set);
		   System.out.println(set1.toString());
		   
		   System.out.println("*******clear()*********");
		   set1.clear();
		   System.out.println(set1.toString());
		   
		   System.out.println("*******contains()*********");	 
		   System.out.println(set.contains(14));
		   
		   System.out.println("*******isEmpty()*********");	 
		   System.out.println(set.isEmpty());
		   System.out.println(set1.isEmpty());
		   
		   System.out.println("*******iterator()*********");
		   Iterator<Integer> iter=set.iterator();
	       while(iter.hasNext()) {
	             System.out.println(iter.next());
	                }
	       
	       System.out.println("*******Spliterator()*********");
	       Spliterator<Integer> spltr=set.spliterator();
	       spltr.forEachRemaining(System.out::println);
	       
	       System.out.println("*******remove()*********");
		   set.remove(18);
		   System.out.println(set.toString());
		   
		   System.out.println("*******size()*********");	 
		   System.out.println(set.size());
		   
		   
		}

}
