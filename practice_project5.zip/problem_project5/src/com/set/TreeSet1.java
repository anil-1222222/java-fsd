package com.set;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.SortedSet;
import java.util.Spliterator;
import java.util.TreeSet;

public class TreeSet1 {
	public static void main(String[] args) {
		   TreeSet<Integer> set=new TreeSet<Integer>();
		   
		   System.out.println("*******Add()*********");
		   set.add(12);
		   set.add(13);
		   set.add(14);
		   set.add(18);
		   set.add(16);
		   set.add(17);
		   set.add(20);
		   set.add(21);
		   set.add(22);
		   set.add(23);
		   System.out.println(set.toString());
		   
		   System.out.println("*******addAll()*********");
		   TreeSet<Integer> set1=new TreeSet<Integer>();
		   set1.addAll(set);
		   System.out.println(set1.toString());
		   
		   System.out.println("*******clear()*********");
		   set1.clear();
		   System.out.println(set1.toString());
		   
		   System.out.println("*******contains()*********");	 
		   System.out.println(set.contains(14));
		   
		   System.out.println("*******isEmpty()*********");	 
		   System.out.println(set.isEmpty());
		   System.out.println(set1.isEmpty());
		   
		   System.out.println("*******iterator()*********");
		   Iterator<Integer> iter=set.iterator();
	       while(iter.hasNext()) {
	             System.out.println(iter.next());
	                }
	       
	       System.out.println("*******descendingiterator()*********");
		   Iterator<Integer> iter1=set.descendingIterator();
	       while(iter1.hasNext()) {
	             System.out.println(iter1.next());
	                }
	       
	       System.out.println("*******Spliterator()*********");
	       Spliterator<Integer> spltr=set.spliterator();
	       spltr.forEachRemaining(System.out::println);
	     
	       
	       System.out.println("*******remove()*********");
		   set.remove(18);
		   System.out.println(set.toString());
		   
		   System.out.println("*******size()*********");	 
		   System.out.println(set.size());
		   
		   System.out.println("*******NavigableSet()*********");
		   NavigableSet set2=set.descendingSet();
		   System.out.println(set2);
		   
		   System.out.println("*******SortedHeadSetSet()*********");
		   SortedSet<Integer> set3=set.headSet(14);
		   System.out.println(set3);
		  
		   System.out.println("******higher()*********");
		   System.out.println(set.higher(14));
		   
		   System.out.println("******lower()*********");
		   System.out.println(set.lower(14));
		   
		   System.out.println("******pollFirst()*********");
		   System.out.println(set.toString());
		   System.out.println(set.pollFirst());
		   System.out.println(set.toString());
		   
		   System.out.println("******pollLast()*********");
		   System.out.println(set.toString());
		   System.out.println(set.pollLast());
		   System.out.println(set.toString());
		   
		   System.out.println("******ElementsB/w*********");
		   NavigableSet<Integer> sub=set.subSet(16, true, 21, false);
		   System.out.println(sub);
		   
		   System.out.println("******ElementsB/w*********");
		   SortedSet<Integer> sub1=set.subSet(17, 22);
		   System.out.println(sub1);
		   
		   System.out.println("*******tailSet*******");
		   SortedSet<Integer> sub2=set.tailSet(20);
		   System.out.println(sub2);
		   
		   System.out.println("******tailSet*********");
		   NavigableSet<Integer> sub3=set.tailSet(14, false);
		   System.out.println(sub3);
		   
		   System.out.println("*******first()*******");
		  System.out.println(set.first());
		  
		  System.out.println("*******last()*******");
		  System.out.println(set.last());
		}


}
