package com.map;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMap1 {

	public static void main(String[] args) {
		Map<Integer, String> map=new LinkedHashMap<>();
		map.put(1,"One");
		map.put(2,"Two");
		map.put(3,"Three");
		map.put(4,"Four");
		map.put(5,"Five");
		map.put(9,"Nine");
		map.put(6,"Six");
		map.put(7,"Seven");
		map.put(8,"Eight");
		
		System.out.println(map);
		
		//Accessing keys
		System.out.println("Keys are: "+map.keySet());
		
		//Accessing Values
	    System.out.println("Values are: "+map.values());
	    
	    //Removing elements
	    String val=map.remove(5);
	    System.out.println("Removing Element: "+val);
	    
	    //updating elements
	    map.put(1,"ONE");
	    System.out.println("After changing : "+map);
	    
	    //Iterating Elements
	    for(Map.Entry<Integer, String> a:map.entrySet() ) {
	    	System.out.println(a.getKey()+" "+a.getValue());
	    }
	    
	    //checks whether map is empty
	    System.out.println("Checks map empty/not :"+map.isEmpty());
	    
	    //To get size of map
	    System.out.println("size of map :"+map.size());
	    
	    //Check whether key present or not
	    System.out.println("checks whether key contains or not :"+map.containsKey(4));
	    
	  //Check whether Value present or not
	    System.out.println("checks whether Value contains or not :"+map.containsValue("Two"));
	    
	    //clear all elements in map
	    map.clear();
	    System.out.println("Cleared all elements in map :"+map);
	    
				
	}

}
