package com.innerClass;

//OuterClass
public class OuterClass {
	//OuterClass Variable
	private String name;
	
	//OuterClass Constructor
	OuterClass(String name) {
		this.name=name;
	}
	//gettor
	String getName() {
		return name;
	}
	
	//Inner Class
	class InnerClass{
		//InnerClass Variable
		private int age;
		//InnerClass Constructor
		 InnerClass(int age){
			 this.age=age;
		 }
		 //Getter
		 int getAge(){{
			 return age;
		 }
	}
	
	}
	public static void main(String[] args) {
		OuterClass ob1=new OuterClass("Anil");
		OuterClass.InnerClass ob2=ob1.new InnerClass(23);
		
		String name=ob1.getName();
		int age=ob2.getAge();
		
		System.out.println("The name in Outer Class ::"+name);
		System.out.println("The age of Inner Class is :"+age);
	}
}
