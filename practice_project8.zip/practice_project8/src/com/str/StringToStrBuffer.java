package com.str;

public class StringToStrBuffer {

	public static void main(String[] args) {
		
		String str=new String("Java");
		
		StringBuffer strBuf=new StringBuffer(str);
	
		System.out.println("=====BufferDetails=====");
		System.out.println("default capacity :"+strBuf.capacity());
		System.out.println("length ::"+strBuf.length());
		System.out.println(strBuf);
		
		strBuf.append(" is");
		System.out.println("=====BufferDetails=====");
		System.out.println("default capacity :"+strBuf.capacity());
		System.out.println("length ::"+strBuf.length());
		System.out.println(strBuf);
		
		strBuf.append(" easy to learn");
		System.out.println("=====BufferDetails=====");
		System.out.println("default capacity :"+strBuf.capacity());
		System.out.println("length ::"+strBuf.length());
		System.out.println(strBuf);
		
		strBuf.insert(8, "Very ");
		System.out.println(strBuf.toString());
		
		strBuf.replace(0, 4, "python");
		System.out.println(strBuf.toString());
		
		strBuf.reverse();
		System.out.println(strBuf.toString());
		
		strBuf.delete(5 , 10);
		System.out.println(strBuf.toString());
		

	}

}
