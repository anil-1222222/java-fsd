package com.array;

import java.util.Scanner;

public class SingleDimensionArray1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array..");
		int n=sc.nextInt();
		
		//initilize and Declaration of array
		int[] arr=new int[n];
		
		//taking inputs from user
		for (int i = 0; i < arr.length; i++) {
			arr[i]=sc.nextInt();
		}
		
		//Display array elemets
		System.out.print("Array Elements are :: ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}

	}

}
