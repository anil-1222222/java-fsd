package com.array;

import java.util.Scanner;

public class TwoDimensionArray1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array..");
		int n=sc.nextInt();
		
		//initilize and Declaration of array
		int[][] arr=new int[n][n];
		
		//taking inputs from user
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				arr[i][j]=sc.nextInt();
			}
			
		}
		
		//Display array elemets
		System.out.println("Array Elements are :: ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}

	}

}
