package com.reg;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {

	public static void main(String[] args) {
		
		String re="[89][0-9]{9}";
		String text="8987665463";
		
		Pattern pt=Pattern.compile(re);
		Matcher mt=pt.matcher(text);
		
	    if(mt.matches()) {
		    System.out.println("Phone Number is Matched..");
	    }
	    else {
	    	System.out.println("Phone Number is Not Matched..");
	    }
	}

}
